﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class SDKInterfaceDefault : U8SDKInterface
{
    public override void Init()
    {
        throw new NotImplementedException();
    }

    public override void Login()
    {
        throw new NotImplementedException();
    }

    public override void LoginCustom(string customData)
    {
        throw new NotImplementedException();
    }

    public override void SwitchLogin()
    {
        throw new NotImplementedException();
    }

    public override bool Logout()
    {
        throw new NotImplementedException();
    }

    public override bool ShowAccountCenter()
    {
        throw new NotImplementedException();
    }

    public override void SubmitGameData(U8ExtraGameData data)
    {
        throw new NotImplementedException();
    }

    public override bool SDKExit()
    {
        throw new NotImplementedException();
    }

    public override void Pay(U8PayParams data)
    {
        throw new NotImplementedException();
    }

    public override bool IsSupportExit()
    {
        throw new NotImplementedException();
    }

    public override bool IsSupportAccountCenter()
    {
        throw new NotImplementedException();
    }

    public override bool IsSupportLogout()
    {
        throw new NotImplementedException();
    }
}