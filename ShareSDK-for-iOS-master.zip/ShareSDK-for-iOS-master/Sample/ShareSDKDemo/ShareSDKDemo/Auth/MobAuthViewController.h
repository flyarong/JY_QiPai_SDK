//
//  MobAuthViewController.h
//  ShareSDKDemo
//
//  Created by youzu on 2017/5/11.
//  Copyright © 2017年 mob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MobAuthViewController : UIViewController

- (void)reload;
@end
