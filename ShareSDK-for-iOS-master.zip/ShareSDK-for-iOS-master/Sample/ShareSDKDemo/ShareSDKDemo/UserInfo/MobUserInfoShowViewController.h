//
//  MobUserInfoShowViewController.h
//  ShareSDKDemo
//
//  Created by youzu on 2017/5/12.
//  Copyright © 2017年 mob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ShareSDK/ShareSDK+Base.h>

@interface MobUserInfoShowViewController : UIViewController

- (void)setUserInfo:(SSDKUser *)userInfo;
@end
