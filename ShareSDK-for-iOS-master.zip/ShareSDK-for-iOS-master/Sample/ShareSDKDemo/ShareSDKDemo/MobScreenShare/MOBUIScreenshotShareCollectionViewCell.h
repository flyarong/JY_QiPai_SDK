//
//  MOBUIScreenshotShareCollectionViewCell.h
//  MobScreenShareDome
//
//  Created by youzu on 17/1/23.
//  Copyright © 2017年 mob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MOBUIScreenshotShareCollectionViewCell : UICollectionViewCell

@property(nonatomic,strong)UIImageView *imageView;
@property(nonatomic,strong)UILabel *titelLabel;
@end
