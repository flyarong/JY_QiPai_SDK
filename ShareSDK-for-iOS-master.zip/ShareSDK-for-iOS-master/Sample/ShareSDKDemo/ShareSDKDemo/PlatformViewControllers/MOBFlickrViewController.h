//
//  MOBFlickrViewController.h
//  ShareSDKDemo
//
//  Created by youzu on 2017/6/7.
//  Copyright © 2017年 mob. All rights reserved.
//

#import "MOBPlatformViewController.h"

@interface MOBFlickrViewController : MOBPlatformViewController

@end
