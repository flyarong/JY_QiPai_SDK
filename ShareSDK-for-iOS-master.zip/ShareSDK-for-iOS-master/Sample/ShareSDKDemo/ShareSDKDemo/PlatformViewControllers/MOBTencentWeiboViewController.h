//
//  MOBTencentWeiboViewController.h
//  ShareSDKDemo
//
//  Created by youzu on 2017/6/5.
//  Copyright © 2017年 mob. All rights reserved.
//

#import "MOBPlatformViewController.h"

@interface MOBTencentWeiboViewController : MOBPlatformViewController

@end
