//
//  MOBMessengerViewController.h
//  ShareSDKDemo
//
//  Created by youzu on 17/3/7.
//  Copyright © 2017年 mob. All rights reserved.
//

#import "MOBPlatformViewController.h"

@interface MOBFacebookViewController : MOBPlatformViewController

@end
