//
//  MOBPinterestViewController.h
//  ShareSDKDemo
//
//  Created by youzu on 2017/6/8.
//  Copyright © 2017年 mob. All rights reserved.
//

#import "MOBPlatformViewController.h"

@interface MOBPinterestViewController : MOBPlatformViewController

@end
