//
//  MOBWhatsAppViewController.h
//  ShareSDKDemo
//
//  Created by youzu on 2017/5/26.
//  Copyright © 2017年 mob. All rights reserved.
//

#import "MOBPlatformViewController.h"

@interface MOBWhatsAppViewController : MOBPlatformViewController

@end
