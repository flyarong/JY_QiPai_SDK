//
//  MOBPrintViewController.h
//  ShareSDKDemo
//
//  Created by youzu on 2017/5/25.
//  Copyright © 2017年 mob. All rights reserved.
//

#import "MOBPlatformViewController.h"

@interface MOBPrintViewController : MOBPlatformViewController

@end
