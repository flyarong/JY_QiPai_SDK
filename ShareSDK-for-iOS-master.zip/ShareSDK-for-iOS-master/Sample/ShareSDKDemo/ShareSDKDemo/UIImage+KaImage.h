//
//  UIImage+KaImage.h
//  JLbao
//
//  Created by anplex_yy on 16/5/12.
//  Copyright © 2016年 anplex. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIImage (KaImage)
+ (UIImage *) getImageWithColor:(UIColor*)color;
@end
