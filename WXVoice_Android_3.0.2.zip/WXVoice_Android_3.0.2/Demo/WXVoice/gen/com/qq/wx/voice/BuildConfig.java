/** Automatically generated file. DO NOT MODIFY */
package com.qq.wx.voice;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}