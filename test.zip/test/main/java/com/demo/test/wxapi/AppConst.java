﻿package com.demo.test.wxapi;

/**
 * Created by Star_Spark on 2016/11/23.
 */

public class AppConst {
    public static String WEIXIN_APP_ID="你的 ID";
    public static String WEIXIN_APP_SECRET ="你的secret";
}
