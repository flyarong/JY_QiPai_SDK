package com.bolaa.douniu.wxapi;

/**
 * Created by Star_Spark on 2016/11/23.
 */

public class AppConst {
    public static String WEIXIN_APP_ID="wxd761e6bdc45a2282";
    public static String WEIXIN_APP_SECRET ="9121d64247bce21010efa166b68d56ae";
}
